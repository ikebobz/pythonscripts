FACILITY INCREMENTAL BACKUP
===========================

Contents
  run_backup.bat      Runs the incremental backup (double-click or schedule)
  backup_config.bat   Facility settings: DB host/port/name/user/password, output folder
  setup.bat           One-time setup: installs Python packages, optional daily schedule
  backup_script.py    Backup engine (exports rows changed since last run)
  restore_script.py   Restores extracted backup .jsonl files into a database
  data_tables.csv     List of tables/columns to back up
  requirements.txt    Python packages (pandas, psycopg2-binary)

Installation at a facility
  1. Install Python 3 (tick "Add python.exe to PATH").
  2. Copy this folder to the facility PC, e.g. C:\FacilityBackup
  3. Edit backup_config.bat with the facility's database details.
  4. Run setup.bat.
  5. Run run_backup.bat for the first (full) backup.

How it works
  - First run: no backups\manifest.json exists, so all records modified after
    INITIAL_LAST_RUN (default 1970) are exported - effectively a full backup.
  - Every later run exports only records changed since the previous run.
  - Each run produces backups\YYYY-MM-DD_HHMMSS.zip and updates manifest.json.
  - Logs are written to logs\backup_*.log.
  - Do NOT delete backups\manifest.json - it holds the incremental checkpoint.

Restore
  Extract the zip(s) in date order and run:
    py -3 restore_script.py --input-dir <extracted folder> --host localhost ^
        --dbname lamisplus --user postgres --password <password>
